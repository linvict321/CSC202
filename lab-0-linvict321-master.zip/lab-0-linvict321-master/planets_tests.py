import unittest
from planets import *

# Write more test cases!

class Test_planets(unittest.TestCase):

    def test_mars(self) -> None:
        weight = 136
        self.assertAlmostEqual(weight_on_planets(weight,"Mars"),51.68)

    def test_error(self) -> None:
        with self.assertRaises(ValueError):  # uses context manager for checking exception
            weight = 99
            weight_on_planets(weight,"Sun")

    def test_venus(self) -> None:
        weight = 100
        self.assertAlmostEqual(weight_on_planets(weight, "Venus"), 91)

    def test_jupiter(self) -> None:
        weight = 100
        self.assertAlmostEqual(weight_on_planets(weight, "Jupiter"), 234)

if __name__ == "__main__":
        unittest.main()
