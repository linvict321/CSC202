from dataclasses import dataclass
from typing import List
from stack_array import *

@dataclass
class Vertex:
    adjacencies: List

    def __post_init__(self) -> None:
        self.in_degree: int = 0     # the number of edges into vertex

def tsort(vertices: List) -> str:
    '''
    * Performs a topological sort of the specified directed acyclic graph.  The
    * graph is given as a list of vertices where each pair of vertices represents
    * an edge in the graph.  The resulting string return value will be formatted
    * identically to the Unix utility {@code tsort}.  That is, one vertex per
    * line in topologically sorted order.
    *
    * Raises a ValueError if:
    *   - vertices is emtpy with the message "input contains no edges"
    *   - vertices has an odd number of vertices (incomplete pair) with the
    *     message "input contains an odd number of tokens"
    *   - the graph contains a cycle (isn't acyclic) with the message 
    *     "input contains a cycle"'''
    if len(vertices) == 0:
        raise ValueError("input contains no edges")
    if len(vertices)%2 != 0:
        raise ValueError("input contains an odd number of tokens")

    dict = {}  # graph w/ all vertices
    vertexes_order = []  # order where vertexes are extracted
    for idx in range(0, len(vertices), 2):
        initial = vertices[idx]
        next = vertices[idx + 1]
        if initial not in dict:
            dict[initial] = Vertex([])
            vertexes_order.append(initial)
        if next not in dict:
            dict[next] = Vertex([])
            vertexes_order.append(next)
        dict[initial].adjacencies.append(next)
        dict[next].in_degree += 1

    result = []
    in_degree0 = stack_zeros(dict, vertexes_order)
    while not in_degree0.is_empty():
        value = in_degree0.pop()
        result.append(value)

        for adjacent_v in dict[value].adjacencies:
            dict[adjacent_v].in_degree -= 1
            if dict[adjacent_v].in_degree == 0:
                in_degree0.push(adjacent_v)
    if len(result) < len(dict):
        raise ValueError("input contains a cycle")

    return '\n'.join(result)

def stack_zeros(graph: dict[str, Vertex], vertex_order: List[str]) -> Stack:
    stack = Stack(len(graph)) #stack all the vertices w/ 0 degrees
    for vertex in vertex_order:
        if graph[vertex].in_degree == 0:
            stack.push(vertex)
    return stack
