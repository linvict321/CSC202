# CPE 202 Location Class Test Cases, Lab 1

import unittest
from location import *

class TestLocation(unittest.TestCase):

    def test_repr(self) -> None:
        loc = Location('SLO', 35.3, -120.7)
        self.assertEqual(repr(loc),"Location('SLO', 35.3, -120.7)")
#checks that the slo location is represented properly
    
    # Add more tests!
    def test_eq(self) -> None:
        loc = Location('SLO', 35.3, -120.7)
        self.assertEqual(loc, Location('SLO', 35.3, -120.7))
        self.assertNotEqual(loc, Location("Paris", 35.3, -120.7))
        self.assertEqual(loc.name, 'SLO')
    #checks that it'll check it equal to by type


    def test_init(self) -> None:
        loc = Location('SLO', 35.3, -120.7)
        self.assertEqual(loc.name, 'SLO')
        self.assertEqual(loc.lat, 35.3)
        self.assertEqual(loc.lon, -120.7)
        self.assertNotEqual(loc.name, 'Paris')
        self.assertNotEqual(loc.lat, 0)
        self.assertNotEqual(loc.lon, -12)


if __name__ == "__main__":
        unittest.main()
