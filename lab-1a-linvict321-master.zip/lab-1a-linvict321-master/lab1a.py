# CPE 202 Lab 1a
from typing import Optional
from typing import List

# Maybe_List (Optional[List]) is either
# Python List
# or
# None

# Maybe_integer (Optional[int]) is either
# integer
# or
# None

# Maybe_List -> Maybe_integer
def max_list_iter(int_list: Optional[List]) -> Optional[int]:
   """finds the max of a list of numbers and returns the value (not the index)
   If int_list is empty, returns None. If list is None, raises ValueError"""
   try:
      if not int_list:
         raise ValueError

      curr_max = int_list[0]
      for idx in int_list:
         if idx > curr_max:
            curr_max = idx
      return curr_max
   except ValueError:
      raise ValueError

# Maybe_List -> Maybe_List
def reverse_list(int_list: Optional[List]) -> Optional[List]:
   """reverses a list of numbers and returns the reversed list
   If list is None, raises ValueError"""
   try:
      if not int_list:
         raise ValueError

      reversed_list = []
      for idx in range(1, len(int_list) + 1):
          reversed_list.append(int_list[-idx])
      return  reversed_list

   except ValueError:
      raise ValueError

# Maybe_List -> None
def reverse_list_mutate(int_list: Optional[List]) -> None:
   """reverses a list of numbers, modifying the input list, returns None
   If list is None, raises ValueError"""
   try:
      if not int_list:
         raise ValueError

      left = 0
      right = len(int_list) - 1

      while left < right:
         temp = int_list[left]
         int_list[left] = int_list[right]
         int_list[right] = temp

         left += 1
         right -= 1

   except ValueError:
      raise ValueError
