from typing import List
# string -> List of strings
# Returns list of permutations for input string
# e.g. 'ab' -> ['ab', 'ba']; 'a' -> ['a']; '' -> ['']
def perm_gen_lex(str_in: str) -> List:

    if len(str_in) == 0:
        return ['']

    final_list = []
    for idx in range(len(str_in)):
        first_let = str_in[idx] #get the character

        rest_of_str = str_in[:idx] + str_in[1+idx:] #get rest of string around the first gotten character

        for jdx in perm_gen_lex(rest_of_str): #get the diff recursed versions
            final_list.append(first_let + jdx) #appends the gotten character and then the diff permutations

    return sorted(final_list) #return in alphabetical order