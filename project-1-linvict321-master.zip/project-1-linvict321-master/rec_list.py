from dataclasses import dataclass
from typing import Tuple, TypeAlias, Union, Optional, Any

StrList: TypeAlias = Union[None, 'Node']   # same as Optional['Node']

@dataclass
class Node:
        value: str
        rest: StrList

MaybeString: TypeAlias = Union[None, str]

# StrList -> MaybeString
# Returns first (as determined by Python compare) string in NodeList
# If NodeList is empty (None), return None
# Must be implemented recursively
def first_string(strlist: StrList) -> MaybeString:

    if strlist is None: #if the nodes had nothing
        return None

    if strlist.rest is None: #if about to hit the end where it is None and there is nothing smaller
        return strlist.value #return the smallest value

    final_answer = first_string(strlist.rest)#continue to check the rest of it

    if final_answer is not None and strlist.value < final_answer: #compares both
        return strlist.value #final answer will be the smaller one
    else:
        return final_answer #run the code again



# StrList -> (StrList, StrList, StrList)
# Returns a tuple with 3 new StrLists,
# the first one with strings from the input list that start with a vowel,
# the second with strings from the input list that start with a consonant,
# the third with strings that don't start with an alpha character
# Must be implemented recursively
def split_list(strlist: StrList) -> Tuple[Optional[StrList], Optional[StrList], Optional[StrList]]:

    if strlist is None: #if the nodes had nothing
        return None, None, None
    vowels = ['a', 'e', 'i', 'o', 'u', 'A', 'E', 'I', 'O', 'U']

    vowels_list, constant_list, misc_list = split_list(strlist.rest) #checks the diff nodes in case there's nothing there

    if strlist.value[0] in vowels:#??????
        return Node(strlist.value, vowels_list), constant_list, misc_list
    elif strlist.value[0].isalpha():
        return vowels_list, Node(strlist.value, constant_list), misc_list
    else:
        return vowels_list, constant_list, Node(strlist.value, misc_list)
