
# Given integer n, returns True or False based on reachability of goal
# See write up for "rules" for bears
def bears(n: int) -> bool: #ask in OH

    if n == 42:
        return True
    elif n < 42:
        return False

    if n%2 == 0 and bears(n - n//2):
        return True

    if n%3 == 0 or n%4 == 0:
        if n >= 42:
            last_num = n%10
            second_last_num = (n//10)%10 #gets second last i.e. 543//10 = 54, 54%10 = 4
            if last_num*second_last_num > 0 and bears(n - last_num*second_last_num):
                return True

    if n%5 == 0 and bears(n - 42):
        return True

    return False