from dataclasses import dataclass
from re import search
from typing import Any, Union, TypeAlias, List

MaybeInt: TypeAlias = Union[None, int]

@dataclass
class Node:
    item: Any               # object reference stored in Node
    next: 'Node' = None     # type: ignore # reference to next Node
    prev: 'Node' = None     # type: ignore # reference to previous Node

# A doubly-linked ordered list of integers, from lowest (head of list, sentinel.next)
# to highest (tail of list, sentinel.prev)
@dataclass
class OrderedList:

    def __post_init__(self) -> None:
        self.sentinel: Node = Node(None)
        self.sentinel.next = self.sentinel
        self.sentinel.prev = self.sentinel

    def is_empty(self) -> bool:
        """Returns back True if OrderedList is empty"""
        if self.sentinel.next == self.sentinel:
            return True
        return False

    def add(self, item: Any) -> None:
        """Adds an item to OrderedList, in the proper location based on ordering of items
        from lowest (at head of list) to highest (at tail of list)
        If item is already in list, do not add again (no duplicate items)"""

        curr = self.sentinel.next
        while curr is not self.sentinel and curr.item < item:
            curr = curr.next #move onto the next item
        if curr != self.sentinel and curr.item == item:
            return
        temp = Node(item)
        temp.next = curr
        temp.prev = curr.prev
        curr.prev.next = temp
        curr.prev = temp

    def remove(self, item: Any) -> bool:
        """Removes an item from OrderedList. If item is removed (was in the list) returns True
        If item was not removed (was not in the list) returns False"""

        curr = self.sentinel.next
        while curr != self.sentinel:
            if curr.item == item:
                curr.prev.next = curr.next
                curr.next.prev = curr.prev
                return True
            curr = curr.next
        return False


    def index(self, item: Any) -> MaybeInt:
        """Returns index of an item in OrderedList (assuming head of list is index 0).
        If item is not in list, return None"""

        index = 0
        curr = self.sentinel.next

        while curr != self.sentinel:
            if curr == self.sentinel or curr.item == item:
                return index
            if curr.item > item:
                return None

            curr = curr.next
            index += 1
        return None

    def pop(self, index: int) -> Any:
        """Removes and returns item at index (assuming head of list is index 0).
        If index is negative or >= size of list, raises IndexError"""

        if index < 0 or index >= self.size():
            raise IndexError
        curr_idx = 0
        finding_idx = index
        curr = self.sentinel.next #add one to current index until it is the same value as the index you want to return, then return the sentinel of that index
        while curr_idx < finding_idx:
            curr_idx += 1
            curr = curr.next

        self.remove(curr.item)
        return curr.item

    def search(self, item: Any) -> bool:
        """Searches OrderedList for item, returns True if item is in list, False otherwise - USE RECURSION"""

        curr = self.sentinel.next
        return self.search_rec_helper(item, curr)

    def search_rec_helper(self, item: Any, curr_node: Node) -> bool:
        #item < current sentinel, keep moving
        #if item == sentinel, return true
        #item > current sentinel, return false

        if curr_node is self.sentinel:
            return False
        if item == curr_node.item:
            return True
        if item < curr_node.item:
            return False
        return self.search_rec_helper(item, curr_node.next)


    def python_list(self) -> List:
        """Return a Python list representation of OrderedList, from head to tail
        For example, list with integers 1, 2, and 3 would return [1, 2, 3]"""
        python_list = []
        curr = self.sentinel.next

        while curr is not self.sentinel: #while it does not point back to the first one
            python_list.append(curr.item)
            curr = curr.next

        return python_list

    def python_list_reversed(self) -> List:
        """Return a Python list representation of OrderedList, from tail to head, USING RECURSION
        For example, list with integers 1, 2, and 3 would return [3, 2, 1]"""
        curr = self.sentinel.prev
        return self.python_list_reversed_helper(curr)

    def python_list_reversed_helper(self, curr_node: Node) -> List:
        if curr_node == self.sentinel:
            return [] #bc this means that it's empty
        
        #othwise, i want to return the prev one
        return [curr_node.item] + self.python_list_reversed_helper(curr_node.prev)

    def size(self) -> int:
        """Returns number of items in the OrderedList - USE RECURSION"""
        counter = 0
        curr = self.sentinel.next
        return self.size_helper(counter, curr)

    def size_helper(self, counter:int, curr_node: Node) -> int:

        if curr_node == self.sentinel:
            return counter

        counter += 1
        next_node = curr_node.next
        return self.size_helper(counter, next_node)