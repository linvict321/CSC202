from queue_array import *
from typing import Union, TypeAlias, Any, List, Tuple
from dataclasses import dataclass

BinSrchTree: TypeAlias = Union['BTNode', None]

MaybeInt: TypeAlias = Union[int, None]
MaybeTuple: TypeAlias = Union[Tuple[Any, Any], None]

@dataclass
class BTNode:
    key: Any                  # key for BTNode, unique ID
    data: Any                 # payload for BTNode
    left: BinSrchTree         # left child (BTNode or None)
    right: BinSrchTree        # right child (BTNode or None)

# returns True if tree is empty, else False
def is_empty(bst: BinSrchTree) -> bool:
    if bst is None:
        return True
    return False

# Inserts new node w/ key and data
# If an item with the given key is already in the BST,
# the data in the tree will be replaced with the new data
def insert(bst: BinSrchTree, new_key: Any, new_data: Any) -> BTNode:
    cur = bst
    if cur is None:
        return BTNode(new_key, new_data, None, None)
    if new_key > cur.key:
        cur.right =  insert(cur.right, new_key, new_data)
    elif new_key < cur.key:
        cur.left = insert(cur.left, new_key, new_data)
    elif new_key == cur.key:
        cur.data = new_data
    return cur

# returns True if target_key is in a node of the tree, else False
def search(bst: BinSrchTree, target_key: Any) -> bool:
    if bst is None:
        return False
    if bst.key == target_key:
        return True
    if target_key > bst.key:
        return search(bst.right, target_key)
    return search(bst.left, target_key)

# returns tuple with min key and associated data in the BST
# returns None if the tree is empty
def find_min(bst: BinSrchTree) -> MaybeTuple:
    if bst is None:
        return None
    cur = bst
    while cur.left is not None:
        cur = cur.left
    return (cur.key, cur.data)

# returns tuple with max key and associated data in the BST
# returns None if the tree is empty
def find_max(bst: BinSrchTree) -> MaybeTuple:
    if bst is None:
        return None
    cur = bst
    while cur.right is not None:
        cur = cur.right
    return (cur.key, cur.data)

# return the height of the tree
# if tree is empty, return None
def tree_height(bst: BinSrchTree) -> MaybeInt:
    if bst is None:
        return None
    if bst.left is None and bst.right is None:
        return 0
    left = tree_height(bst.left)
    right = tree_height(bst.right)
    if left is None:
        left = -1
    if right is None:
        right = -1
    return 1 + max(left, right)

# return Python list of BST keys representing inorder traversal of BST
def inorder_list(bst: BinSrchTree) -> List[Any]:
    if bst is None:
        return []
    left_side = inorder_list(bst.left)
    right_side = inorder_list(bst.right)
    return left_side + [bst.key] + right_side

# return Python list of BST keys representing preorder traversal of BST
def preorder_list(bst: BinSrchTree) -> List[Any]:
    if bst is None:
        return []
    left_side = inorder_list(bst.left)
    right_side = inorder_list(bst.right)
    return [bst.key] + left_side + right_side

# return Python list of BST keys representing level-order traversal of BST
# You MUST use your queue_array data structure from lab 3 to implement this method
def level_order_list(bst: BinSrchTree) -> List[Any]:
    q = Queue(100)
    final = []
    if bst is None:
        return []
    q.enqueue(bst)

    while not q.is_empty():
        temp = q.dequeue()
        final.append(temp.key)

        if temp.left is not None:
            q.enqueue(temp.left)
        if temp.right is not None:
            q.enqueue(temp.right)

    return final
