import unittest
from binary_search_tree import *

class TestLab4(unittest.TestCase):
    def test_is_empty(self) -> None:
        bst: BinSrchTree = None
        self.assertEqual(True, is_empty(bst))
        bst = insert(bst, 55,"abc")
        self.assertEqual(False, is_empty(bst))

    def test_insert(self) -> None:
        bst: BinSrchTree = None
        bst = insert(bst, 55,"abc")
        self.assertEqual(BTNode(55,"abc",None,None),bst)
        bst = insert(bst, 34, "def")
        self.assertEqual(BTNode(55,"abc",BTNode(34,"def",None,None),None),bst)
        bst = insert(bst, 72, "ghi")
        self.assertEqual(BTNode(55, "abc",
                         BTNode(34, "def", None, None),
                         BTNode(72,"ghi",None,None)), bst)

        bst = insert(bst, 72, "ihg")
        self.assertEqual(BTNode(55, "abc",
                                BTNode(34, "def", None, None),
                                BTNode(72, "ihg", None, None)), bst)


    def test_inorder(self) -> None:
        bst: BinSrchTree = None
        self.assertEqual([], inorder_list(bst))
        bst = insert(bst, 55,"abc")
        bst = insert(bst, 34, "def")
        bst = insert(bst, 72, "ghi")
        self.assertEqual([34, 55, 72], inorder_list(bst))
        bst = insert(bst, 44, 'jkl')
        self.assertEqual([34, 44, 55, 72], inorder_list(bst))


    def test_search(self) -> None:
        bst: BinSrchTree = None
        bst = insert(bst, 55, "abc")
        bst = insert(bst, 34, "def")
        bst = insert(bst, 72, "ghi")
        self.assertEqual(search(bst, 55), True)
        self.assertEqual(search(bst, 34), True)
        self.assertEqual(search(bst, 72), True)
        self.assertEqual(search(bst, 100), False)

    def test_empty(self) -> None:
        bst: BinSrchTree = None
        self.assertTrue(is_empty(bst))
        bst = insert(bst, 45, "a")
        self.assertFalse(is_empty(bst))

    def test_find_min_max(self) -> None:
        bst: BinSrchTree = None
        self.assertEqual(None, find_min(bst))
        self.assertEqual(None, find_max(bst))
        bst = insert(bst, 55, "abc")
        bst = insert(bst, 34, "def")
        bst = insert(bst, 72, "ghi")
        self.assertEqual(find_min(bst), (34, 'def'))
        self.assertEqual(find_max(bst), (72, 'ghi'))

    def test_height(self) -> None:
        bst: BinSrchTree = None
        self.assertEqual(tree_height(bst), None)
        bst = insert(bst, 55, "abc")
        bst = insert(bst, 34, "def")
        bst = insert(bst, 72, "ghi")
        self.assertEqual(tree_height(bst), 1)
        bst = insert(bst, 44, 'jkl')
        self.assertEqual(tree_height(bst), 2)
        bst = insert(bst, 62, 'mno')
        self.assertEqual(tree_height(bst), 2)

    def test_preorder_list(self) -> None:
        bst: BinSrchTree = None
        self.assertEqual([], preorder_list(bst))
        bst = insert(bst, 55, "abc")
        bst = insert(bst, 34, "def")
        bst = insert(bst, 72, "ghi")
        self.assertEqual([55, 34, 72], preorder_list(bst))

    def test_level_order_list(self) -> None:
        bst: BinSrchTree = None
        self.assertEqual([], level_order_list(bst))
        bst = insert(bst, 55, "abc")
        bst = insert(bst, 34, "def")
        bst = insert(bst, 72, "ghi")
        self.assertEqual([55, 34, 72], level_order_list(bst))
        bst = insert(bst, 44, 'jkl')
        self.assertEqual([55, 34, 72, 44], level_order_list(bst))


if __name__ == '__main__': 
    unittest.main()
