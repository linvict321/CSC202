import unittest
from queue_array import Queue

class TestLab1(unittest.TestCase):

    def test_array(self) -> None:
        q = Queue(5)
        self.assertEqual(q.items, [None, None, None, None, None])
        self.assertEqual(q.get_items(), [])
        q.enqueue(1)
        self.assertEqual(q.items, [1, None, None, None, None])
        q.enqueue(2)
        self.assertEqual(q.items, [1, 2, None, None, None])

    def test_get_items(self) -> None:
        q = Queue(5)
        q.enqueue(1)
        q.enqueue(2)
        q.enqueue(3)
        self.assertEqual([1, 2, 3], q.get_items())
        q.enqueue(4)
        q.enqueue(5)
        q.dequeue()
        q.enqueue(6)
        self.assertEqual([2, 3, 4, 5, 6], q.get_items())

# WRITE MORE TESTS!

    def test_is_empty(self) -> None:
        q = Queue(50)
        self.assertTrue(q.is_empty())
        self.assertFalse(q.is_full())

    def test_is_full(self) -> None:
        q = Queue(3)
        q.enqueue(10)
        q.enqueue(2)
        q.enqueue(3)
        self.assertTrue(q.is_full())
        self.assertFalse(q.is_empty())

    def test_enqueue_index_error(self) -> None:
        q = Queue(3)
        q.enqueue(10)
        q.enqueue(2)
        q.enqueue(3)
        with self.assertRaises(IndexError):
            q.enqueue(4)

    def test_dequeue_index_error(self) -> None:
        q = Queue(3)
        with self.assertRaises(IndexError):
            q.dequeue()

    def test_size(self) -> None:
        q = Queue(2)
        self.assertEqual(q.size(), 0)
        q.enqueue(2)
        self.assertEqual(q.size(), 1)

if __name__ == '__main__':
    unittest.main()
