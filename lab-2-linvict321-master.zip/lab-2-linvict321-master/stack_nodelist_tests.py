import unittest
from stack_nodelist import *
        
class TestLab2(unittest.TestCase):

    # WRITE TESTS FOR STACK OPERATIONS - PUSH, POP, PEEK, etc.

    def test_is_empty(self) -> None:
        stack = Stack()
        self.assertTrue(stack.is_empty())

    def test_push(self) -> None:
        stack = Stack()
        stack.push(5)
        self.assertEqual(stack.top, Node(5, None))
        self.assertEqual(stack.num_items, 1)

    def test_pop(self) -> None:
        stack = Stack()
        stack.push(5)
        stack.push(10)
        stack.pop()
        self.assertEqual(stack.num_items, 1)
        self.assertEqual(stack.top, Node(5, None))

    def test_pop2(self) -> None:
        stack = Stack()
        with self.assertRaises(IndexError):
            stack.pop()

    def test_peek(self) -> None:
        stack = Stack()
        stack.push(5)
        stack.push(10)
        self.assertTrue(stack.peek(), 10)

    def test_peek2(self) -> None:
        stack = Stack()
        with self.assertRaises(IndexError):
            stack.peek()

    def test_size(self) -> None:
        stack = Stack()
        stack.push(5)
        stack.push(10)
        self.assertEqual(2, stack.size())

    def test_mixedops1(self) -> None:
        stack = Stack()
        stack.push(5)
        stack.push(10)
        self.assertTrue(stack.peek(), Node(10, None))
        stack.pop()
        stack.pop()
        self.assertEqual(0, stack.size())
        self.assertTrue(stack.is_empty())

if __name__ == '__main__':
    unittest.main()
