import unittest
from stack_array import Stack
        
class TestLab2(unittest.TestCase):

# WRITE TESTS FOR STACK OPERATIONS - PUSH, POP, PEEK, etc.

    def test_is_empty(self) -> None:
        stack = Stack(5)
        self.assertTrue(stack.is_empty())

    def test_is_full(self) -> None:
        stack = Stack(2)
        stack.push('1')
        stack.push('2')
        self.assertTrue(stack.is_full())

    def test_push(self) -> None:
        stack = Stack(5)
        stack.push(1)
        self.assertEqual(1, stack.num_items)

    def test_push2(self) -> None:
        stack = Stack(2)
        stack.push(1)
        stack.push(2)
        with self.assertRaises(IndexError):
            stack.push(3)

    def test_pop(self) -> None:
        stack = Stack(2)
        stack.push('a')
        stack.push('b')
        stack.pop()
        self.assertEqual(1, stack.num_items)

    def test_pop2(self) -> None:
        stack = Stack(2)
        with self.assertRaises(IndexError):
            stack.pop()

    def test_peek(self) -> None:
        stack = Stack(2)
        stack.push('a')
        stack.push('b')
        self.assertEqual(stack.peek(), 'b')

    def test_peek2(self) -> None:
        stack = Stack(2)
        with self.assertRaises(IndexError):
            stack.peek()

    def test_size(self) -> None:
        stack = Stack(3)
        stack.push('a')
        stack.push('b')
        self.assertEqual(stack.size(), 2)

    def test_mixedops1(self) -> None:
        stack = Stack(3)
        stack.push(1)
        stack.push(2)
        stack.pop()
        stack.push(3)
        self.assertEqual(2, stack.size())
        self.assertEqual(3, stack.peek())

if __name__ == '__main__': 
    unittest.main()
