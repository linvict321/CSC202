import unittest
from huffman import *

class TestList(unittest.TestCase):
    def test_cnt_freq(self) -> None:
        freqlist = cnt_freq("file2.txt")
        anslist = [2, 4, 8, 16, 0, 2, 0]
        self.assertListEqual(freqlist[97:104], anslist)

    def test_combine(self) -> None:
        a = HuffmanNode(67, 1)
        b = HuffmanNode(66, 2)
        c = combine(a, b)
        if (c.left is not None) and (c.right is not None):
            self.assertEqual(c.left.char_ascii,67)
            self.assertEqual(c.left.freq, 1)
            self.assertEqual(c.right.char_ascii, 66)
            self.assertEqual(c.right.freq, 2)
            self.assertEqual(c.char_ascii, 66)
            self.assertEqual(c.freq, 3)
        else:   # pragma: no cover
            self.fail()
        c = combine(b, a)
        if (c.left is not None) and (c.right is not None):
            self.assertEqual(c.left.char_ascii,67)
            self.assertEqual(c.left.freq, 1)
            self.assertEqual(c.right.char_ascii, 66)
            self.assertEqual(c.right.freq, 2)
            self.assertEqual(c.char_ascii, 66)
            self.assertEqual(c.freq, 3)
        else:   # pragma: no cover
            self.fail()

    def test_create_huff_tree(self) -> None:
        freqlist = cnt_freq("file2.txt")
        hufftree = create_huff_tree(freqlist)
        if hufftree is not None:
            self.assertEqual(hufftree.freq, 32)
            self.assertEqual(hufftree.char_ascii, 97)
            left = hufftree.left
            right = hufftree.right
            if (left is not None) and (right is not None):
                self.assertEqual(left.freq, 16)
                self.assertEqual(left.char_ascii, 97)
                self.assertEqual(right.freq, 16)
                self.assertEqual(right.char_ascii, 100)
            else: # pragma: no cover
                self.fail()
        else: # pragma: no cover
            self.fail()

    def test_create_header(self) -> None:
        freqlist = cnt_freq("file2.txt")
        self.assertEqual(create_header(freqlist), "97 2 98 4 99 8 100 16 102 2")

    def test_create_code(self) -> None:
        freqlist = cnt_freq("file2.txt")
        hufftree = create_huff_tree(freqlist)
        codes = create_code(hufftree)
        self.assertEqual(codes[ord('d')], '1')
        self.assertEqual(codes[ord('a')], '0000')
        self.assertEqual(codes[ord('f')], '0001')

    def test_01_textfile(self) -> None:
        huffman_encode("file1.txt", "file1_out.txt")
        # capture errors by comparing your encoded file with a *known* solution file
        self.assertTrue(compare_files("file1_out.txt", "file1_soln.txt"))
        huffman_encode('file2.txt', 'file2_out.txt')
        self.assertTrue(compare_files('file2_out.txt', 'file2_soln.txt'))

    def test_misc(self) -> None:
        a = HuffmanNode(67, 1)
        b = HuffmanNode(66, 2)
        self.assertTrue(comes_before(a, b))

        freqlist = cnt_freq("emptyfile")
        self.assertEqual(None, create_huff_tree(freqlist))
        freqlist2 = cnt_freq("one_char.txt")
        tree = create_huff_tree(freqlist2)
        self.assertIsNotNone(tree)
        if tree:
            self.assertEqual(97, tree.char_ascii)

        with self.assertRaises(FileNotFoundError):
            huffman_encode("sample", "sample2")

        huffman_encode('emptyfile', "emptyfile_out.txt")
        with open("emptyfile_out.txt") as f:
            content = f.read()
        self.assertEqual(content, "")

        huffman_encode('one_char.txt', "one_char_out.txt")
        with open("one_char_out.txt") as f:
            lines = f.readlines()
        self.assertEqual(len(lines), 1)
        self.assertTrue(lines[0].startswith("97 1"))

        node1 = HuffmanNode(97, 5)
        codes = create_code(node1)
        self.assertEqual(codes[97], '')

    def test_huffman3b(self) -> None:
        huffman_encode("file1.txt", "file1_out.txt")
        # capture errors by comparing your encoded file with a *known* solution file
        self.assertTrue(compare_files("file1_out.txt", "file1_soln.txt"))
        huffman_decode("file1_out.txt", "file1_outdecoded.txt")
        self.assertTrue(compare_files('file1_outdecoded.txt', 'file1.txt'))

        huffman_encode('file2.txt', 'file2_out.txt')
        self.assertTrue(compare_files('file2_out.txt', 'file2_soln.txt'))
        huffman_decode("file2_soln.txt", "file2_outdecoded.txt")
        self.assertTrue(compare_files('file2_outdecoded.txt', 'file2.txt'))

        huffman_encode('one_char.txt', "one_char_out.txt")
        huffman_decode('one_char_out.txt', 'one_char_out_decoded.txt')
        self.assertTrue('one_char.txt', 'one_char_out_decoded.txt' )

        huffman_encode('emptyfile', "emptyfile_out.txt")
        huffman_decode('emptyfile_out.txt', 'emptyfile_out_decoded.txt')
        self.assertTrue('emptyfile.txt', 'emptyfile_out_decoded.txt')

        with self.assertRaises(FileNotFoundError):
            huffman_decode('nocase.txt', 'nocase.txt')

        huffman_decode('invalid_code.txt', 'invalid_output.txt')
        self.assertTrue('invalid_output.txt', 'emptyfile')
        with open("invalid_output.txt", "r") as f:
            result = f.read()
            print("Decoded output:", repr(result))


# Compare files - takes care of CR/LF, LF issues
def compare_files(file1: str, file2: str) -> bool: # pragma: no cover
    match = True
    done = False
    with open(file1, "r") as f1:
        with open(file2, "r") as f2:
            while not done:
                line1 = f1.readline().strip()
                line2 = f2.readline().strip()
                if line1 == '' and line2 == '':
                    done = True
                if line1 != line2:
                    done = True
                    match = False
    return match


if __name__ == '__main__':
    unittest.main()
