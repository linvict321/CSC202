from dataclasses import dataclass
from typing import List, Union, TypeAlias
from typing import Optional

HTree: TypeAlias = Union[None, 'HuffmanNode']

@dataclass
class HuffmanNode:
    char_ascii: int         # stored as an integer - the ASCII character code value
    freq: int               # the frequency associated with the node
    left: HTree = None      # Huffman tree (node) to the left
    right: HTree = None     # Huffman tree (node) to the right

    def __lt__(self, other: 'HuffmanNode') -> bool:
        return comes_before(self, other)


def comes_before(a: HuffmanNode, b: HuffmanNode) -> bool:
    """Returns True if tree rooted at node a comes before tree rooted at node b, False otherwise"""
    if a.freq < b.freq:
        return True
    elif a.freq == b.freq:
        return a.char_ascii < b.char_ascii
    return False

def combine(a: HuffmanNode, b: HuffmanNode) -> HuffmanNode:
    """Creates a new Huffman node with children a and b, with the "lesser node" on the left
    The new node's frequency value will be the sum of the a and b frequencies
    The new node's char value will be the lower of the a and b char ASCII values"""
    if comes_before(a, b):
        new_left, new_right = a, b
    else:
        new_left, new_right = b, a
    new_char = min(a.char_ascii, b.char_ascii)

    return HuffmanNode(new_char, new_right.freq + new_left.freq, new_left, new_right)

def cnt_freq(filename: str) -> List:
    """Opens a text file with a given file name (passed as a string) and counts
    the frequency of occurrences of all the characters within that file
    Returns a Python List with 256 entries - counts are initialized to zero.
    The ASCII value of the characters are used to index into this list for the frequency counts"""
    freq_list = [0]*256

    with open(filename, 'r') as reading_file:
        for line in reading_file:
            for char in line:
                ascii_val = ord(char)
                if 0 <= ascii_val < 256:
                    freq_list[ascii_val] += 1
    return freq_list

def create_huff_tree(char_freq: List) -> HTree:
    """Input is the list of frequencies (provided by cnt_freq()).
    Create a Huffman tree for characters with non-zero frequency
    Returns the root node of the Huffman tree. Returns None if all counts are zero."""
    treelist = []
    for ascii_val in range(256):
        if char_freq[ascii_val] > 0:
            treelist.append(HuffmanNode(ascii_val, char_freq[ascii_val]))

    if not treelist:
        return None
    if len(treelist) == 1:
        return treelist[0]

    treelist.sort()
    while len(treelist) > 1:
        left = treelist.pop(0)
        right = treelist.pop(0)
        combined_ab = combine(left, right)
        j = 0
        while j < len(treelist) and comes_before(treelist[j], combined_ab):
            j += 1
        treelist.insert(j, combined_ab)

    return treelist[0]

def create_code(node: HTree) -> List:
    """Returns an array (Python list) of Huffman codes. For each character, use the integer ASCII representation
    as the index into the array, with the resulting Huffman code for that character stored at that location.
    Characters that are unused should have an empty string at that location"""
    codes = [""] * 256
    def traverse_through(node2: HuffmanNode, curr_code: str) -> None:
        if node2.left is None and node2.right is None:
            codes[node2.char_ascii] = curr_code #puts the curr code into the codes list
            return #it's only a leaf node
        if node2.left is not None:
            traverse_through(node2.left, curr_code + "0")
        if node2.right is not None:
            traverse_through(node2.right, curr_code + "1")

    if node is not None:
        traverse_through(node, "")

    return codes


def create_header(freqs: List) -> str:
    """Input is the list of frequencies (provided by cnt_freq()).
    Creates and returns a header for the output file
    Example: For the frequency list associated with "aaabbbbcc, would return “97 3 98 4 99 2” """
    header = []
    for ascii_val in range(len(freqs)):
        freq = freqs[ascii_val]
        if freq > 0:
            header.append(f"{ascii_val} {freq}")
    return " ". join(header)

def huffman_encode(in_file: str, out_file: str) -> None:
    """Takes inout file name and output file name as parameters
    Uses the Huffman coding process on the text from the input file and writes encoded text to output file
    Take not of special cases - empty file and file with only one unique character"""
    try:
        freq_list = cnt_freq(in_file)
    except FileNotFoundError:
        raise FileNotFoundError

    root = create_huff_tree(freq_list)
    if root is None:
        with open(out_file, 'w') as file:
            file.write('')
        return
    code_list = create_code(root)
    header = create_header(freq_list)

    if root.left is None and root.right is None:
        encoded_text = ''
    else:
        with open(in_file, 'r') as infile:
            text = infile.read()
        encoded_text = ''.join([code_list[ord(char)] for char in text])

    with open(out_file, 'w') as file:
        file.write(header + '\n')
        file.write(encoded_text)

def huffman_decode(encoded_file: str, decode_file: str) -> None:
    try:
        encoded = open(encoded_file, 'r')
    except:
        raise FileNotFoundError

    first_line_read = encoded.readline().strip()
    rest_of_text = encoded.read().strip()
    encoded.close()

    freq_list = parse_header(first_line_read)
    root = create_huff_tree(freq_list)

    if root is None: #nothing in the tree
        with open(decode_file, "w") as out_file:
            out_file.write(" ")
        return

    decoded_text_list = []
    current: Optional[HuffmanNode] = root

    for idx in rest_of_text:
        if current is None:
            break
        if idx == "0":
            current = current.left
        elif idx == "1":
            current = current.right
        if current is not None and current.left is None and current.right is None:
            decoded_text_list.append(chr(current.char_ascii))
            current = root

    with open(decode_file, 'w') as outfile:
        outfile.write(''.join(decoded_text_list))

def parse_header(header_string: str) -> List:
    freq_list = [0]*256
    header_list = header_string.strip().split() #convert to list [97, 3, 99, 5...]
    for idx in range(0, len(header_list), 2):
        freq_list[int(header_list[idx])] = int(header_list[idx + 1])
    return freq_list
