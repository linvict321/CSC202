from dataclasses import dataclass
from typing import Any, Tuple, List

@dataclass
class MyHashTable:
    table_size: int = 11        # default table size is 11

    def __post_init__(self) -> None:
        self.hash_table: List = [[] for _ in range(self.table_size)]  # List of lists implementation
        self.num_items = 0          # No items in hash table at start
        self.num_collisions = 0     # No collisions at start


    def insert(self, key: int, value: Any) -> None:
        """Takes a key, and an item.  Keys are valid Python non-negative integers.
        If key is negative, raise ValueError exception
        The function will insert the key-item pair into the hash table based on the
        hash value of the key mod the table size (hash_value = key % table_size)"""
        if key < 0:
            raise ValueError

        hash_value = key%self.table_size

        existing_key = False
        for k, _ in self.hash_table[hash_value]:
            if k == key:
                existing_key = True
                break
        if self.hash_table[hash_value] and not existing_key: #if there is value inside, and no prev existing key
            self.num_collisions += 1

        for i, (alr_exists_key, alr_exists_value) in enumerate(self.hash_table[hash_value]):
            if alr_exists_key == key:
                self.hash_table[hash_value][i] = (key, value)
                return

        self.hash_table[hash_value].append((key, value))
        self.num_items += 1

        if self.load_factor() > 1.5:
            self.resize()

    def resize(self) -> None:
        old_collisions = self.num_collisions
        old_table = self.hash_table

        self.num_items = 0
        self.table_size = self.table_size*2 + 1
        self.hash_table = [[] for _ in range(self.table_size)]

        for idx in old_table:
            for jdx, (alr_exists_key, alr_exists_value) in enumerate(idx):
                hash_value = alr_exists_key % self.table_size
                self.hash_table[hash_value].append((alr_exists_key, alr_exists_value))
                self.num_items += 1

        self.num_collisions = old_collisions

    def get_item(self, key: int) -> Any:
        """Takes a key and returns the item from the hash table associated with the key.
        If no key-item pair is associated with the key, the function raises a LookupError exception."""

        hash_value = key % self.table_size
        for i, (alr_exists_key, alr_exists_value) in enumerate(self.hash_table[hash_value]):
            if alr_exists_key == key:
                return alr_exists_value
            else:
                raise LookupError

    def remove(self, key: int) -> Tuple[int, Any]:
        """Takes a key, removes the key-item pair from the hash table and returns the key-item pair.
        If no key-item pair is associated with the key, the function raises a LookupError exception.
        (The key-item pair should be returned as a tuple)"""
        hash_value = key % self.table_size
        for i, (alr_exists_key, alr_exists_value) in enumerate(self.hash_table[hash_value]):
            if alr_exists_key == key:
                self.num_items -= 1
                return self.hash_table[hash_value].pop(i)
        raise LookupError

    def load_factor(self) -> float:
        """Returns the current load factor of the hash table"""
        return self.size()/self.table_size

    def size(self) -> int:
        """Returns the number of key-item pairs currently stored in the hash table"""
        return self.num_items

    def collisions(self) -> int:
        """Returns the number of collisions that have occurred during insertions into the hash table"""
        return self.num_collisions