from dataclasses import dataclass
from typing import List, Any, Optional

@dataclass
class HashTable:
    table_size: int                                         # Initial hash table size

    def __post_init__(self) -> None:
        self.hash_table: List = [None]*self.table_size      # Hash table
        self.num_items: int = 0                             # Empty hash table

    def insert(self, key: str, value: Any) -> None:
        """ Inserts an entry into the hash table (using Horner hash function to determine index, 
        and quadratic probing to resolve collisions).
        The key is a string (a word) to be entered, and value is any object (e.g. Python List).
        If the key is not already in the table, the key is inserted along with the associated value
        If the key is in the table, the new value replaces the existing value.
        When used with the concordance, value is a Python List of line numbers.
        If load factor is greater than 0.5 after an insertion, hash table size should be increased (doubled, 
        and then incremented to next prime value)."""

        if (self.num_items + 1) / self.table_size > 0.5:
            self.resize()

        idx = self.horner_hash(key)
        original_idx = idx
        i = 1

        while self.hash_table[idx] is not None:
            if self.hash_table[idx][0] == key:
                self.hash_table[idx] = (key, value)
                return
            idx = (original_idx + i * i) % self.table_size
            i += 1
        self.hash_table[idx] = (key, value)
        self.num_items += 1
        '''
        if self.hash_table[idx] is None:
            self.hash_table[idx] = [key, value]
            self.num_items += 1
            return
        else:
            while self.hash_table[idx] is not None:
                if self.hash_table[idx][0] == key:
                    self.hash_table[idx] = [key, value]  # Replace existing value
                    return
                idx = (idx + i * i) % self.table_size
                i += 1
            self.hash_table[idx] = [key, value]
            self.num_items += 1'''

    def resize(self) -> None:
        old_table = self.hash_table
        self.table_size = self.next_prime(self.table_size * 2)
        self.hash_table = [None] * self.table_size
        self.num_items = 0

        for idx in old_table:
            if idx is not None:
                self.insert(idx[0], idx[1])

    def next_prime(self, input_int: int) -> int:
        def is_prime(x: int) -> bool:
            if x == 2 or x == 3:
                return True
            if x <= 1 or x % 2 == 0 or x % 3 == 0:
                return False
            i = 5
            while i * i <= x:
                if x % i == 0 or x % (i + 2) == 0:
                    return False
                i += 6
            return True
        while is_prime(input_int) is False:
            input_int += 1
        return input_int

    def horner_hash(self, key: str) -> int:
        """ Compute and return an integer from 0 to the (size of the hash table) - 1
        Compute the hash value by using Horner’s rule, as described in project specification."""
        n = min(8, len(key))
        hash_val = 0
        for i in range(n):
            hash_val = hash_val*31 + ord(key[i])
        return hash_val % self.table_size

    def in_table(self, key: str) -> bool:
        """ Returns True if key is in an entry of the hash table, False otherwise. Must be O(1)."""
        if self.get_index(key) is not None:
            return True
        return False

    def get_index(self, key: str) -> Optional[int]:
        """ Returns the index of the hash table entry containing the provided key. 
        If there is not an entry with the provided key, returns None. Must be O(1)."""
        idx = self.horner_hash(key)
        original_idx = idx
        cur_probe = 1 #first probe starts at 1
        max_probe = self.table_size #load factor <= .5

        while self.hash_table[idx] is not None:
            if self.hash_table[idx][0] == key:
                return idx
            idx = (original_idx + cur_probe*cur_probe) % self.table_size
            cur_probe += 1

        return None

    def get_all_keys(self) -> List:
        """ Returns a Python list of all keys in the hash table."""
        final = []
        for n in self.hash_table:
            if n is not None:
                final.append(n[0])
        return final

    def get_value(self, key: str) -> Any:
        """ Returns the value (for concordance, list of line numbers) associated with the key.
        If key is not in hash table, returns None. Must be O(1)."""
        index_val = self.get_index(key)
        if index_val is not None:
            return self.hash_table[index_val][1]
        return None

    def get_num_items(self) -> int:
        """ Returns the number of entries (words) in the table. Must be O(1)."""
        return self.num_items

    def get_table_size(self) -> int:
        """ Returns the size of the hash table."""
        return self.table_size

    def get_load_factor(self) -> float:
        """ Returns the load factor of the hash table (entries / table_size)."""
        return self.num_items/self.table_size
