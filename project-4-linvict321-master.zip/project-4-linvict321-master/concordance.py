from dataclasses import dataclass
from typing import Union, TypeAlias
from hash_quad import *
import string

MaybeHT: TypeAlias = Union[None, HashTable]     # HashTable or None

@dataclass
class Concordance:

    def __post_init__(self) -> None:
        self.stop_table: MaybeHT = None                     # the hash table for stop words
        self.concordance_table: HashTable = HashTable(191)  # the hash table for concordance

    def load_stop_table(self, filename: str) -> None:
        """ Read stop words from input file (filename) and insert each word as a key into the stop words hash table.
        Starting size of hash table should be 191: self.stop_table = HashTable(191)
        If file does not exist, raise FileNotFoundError"""
        try:
            self.stop_table = HashTable(191)
            with open(filename, 'r') as file:
                for line in file:
                    hash_list = line.lower().strip('\n')
                    if hash_list.isalpha():
                        self.stop_table.insert(hash_list.lower(), 0)
        except:
            raise FileNotFoundError

    def load_concordance_table(self, filename: str) -> None:
        """ Read words from input text file (filename) and insert them into the concordance hash table, 
        after processing for punctuation, numbers and filtering out words that are in the stop words hash table.
        Do not include duplicate line numbers (word appearing on same line more than once, just one entry for that line)

        Process of adding new line numbers for a word (key) in the concordance:
            If word is in table, get current value (list of line numbers), append new line number, insert (key, value)
            If word is not in table, insert (key, value), where value is a Python List with the line number
        If file does not exist, raise FileNotFoundError """

        try:
            self.concordance_table = HashTable(191)
            with open(filename, 'r+') as file:
                for line_num, line in enumerate(file, start = 1):
                    duplicates = set()
                    line = line.lower()
                    line = line.replace('-', ' ')
                    line = line.replace("'s", "s")

                    for raw_word in line.strip().split():
                        word = raw_word.strip(string.punctuation)

                        if word.isalpha() and word:
                            if self.stop_table is not None and not self.stop_table.in_table(word):
                                if word not in duplicates:
                                    duplicates.add(word)
                                    existing = self.concordance_table.get_value(word)
                                    if existing is None:
                                        self.concordance_table.insert(word, [line_num])
                                    else:
                                        if line_num not in existing:
                                            existing.append(line_num)
        except FileNotFoundError:
            raise

    def write_concordance(self, filename: str) -> None:
        """ Write the concordance entries to the output file(filename)
        See sample output files for format. """
        all_keys = self.concordance_table.get_all_keys()
        all_keys_sorted = sorted(all_keys)
        with open(filename, 'w') as file:
            lines = []
            for key in all_keys_sorted:
                line_num = self.concordance_table.get_value(key)
                if line_num is not None:
                    line_num = sorted(line_num)
                    output_line = f"{key}: {' '.join(str(line) for line in line_num)}"
                    lines.append(output_line)
            file.write("\n".join(lines))

            