import unittest
from queue_nodelist import *

class TestLab1(unittest.TestCase):

    def test_nodelist(self) -> None:
        q = Queue()
        self.assertEqual(q.rear, None)
        self.assertEqual(q.front, None)
        q.enqueue(1)
        self.assertEqual(q.rear, Node(1, None))
        self.assertEqual(q.front, None)
        q.enqueue(2)
        self.assertEqual(q.rear, Node(2, Node(1, None)))
        self.assertEqual(q.dequeue(),1)
        self.assertEqual(q.rear, None)
        self.assertEqual(q.front, Node(2, None))

    def test_get_items(self)->None:
        q = Queue()
        q.enqueue(1)
        q.enqueue(2)
        q.enqueue(3)
        q.enqueue(4)
        q.enqueue(5)
        q.dequeue()
        q.enqueue(6)
        self.assertEqual([2,3,4,5,6], q.get_items())

# WRITE MORE TESTS!
    def test_isempty(self) -> None:
        q = Queue()
        self.assertTrue(q.is_empty())
        q.enqueue(3)
        self.assertFalse(q.is_empty())

    def test_size(self) -> None:
        q = Queue()
        self.assertEqual(0, q.size())
        q.enqueue(3)
        q.enqueue(4)
        q.dequeue()
        self.assertEqual(1, q.size())
        q.enqueue(5)
        self.assertEqual([4, 5], q.get_items())
        q.dequeue()
        q.dequeue()
        with self.assertRaises(IndexError):
            q.dequeue()

    def test_dequeue(self) -> None:
        q = Queue()
        self.assertEqual(0, q.size())
        q.enqueue(3)
        q.dequeue()
        with self.assertRaises(IndexError):
            q.dequeue()

if __name__ == '__main__': 
    unittest.main()
