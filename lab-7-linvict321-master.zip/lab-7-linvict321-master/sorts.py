import random
import time

def selection_sort(alist):
    counter = 0
    for i in range(len(alist)):
        min_idx = i
        for j in range(i + 1, len(alist)):
            counter += 1
            if alist[j] < alist[min_idx]:  # if the next one is bigger
                temp = alist[j]
                alist[j] = alist[i]
                alist[i] = temp
    return counter

def insertion_sort(alist):
    #if i is smaller than i + 1, then swap, and then keep checking if its smaller than all the ones to the left
    comp_counter = 0
    for i in range(1, len(alist)): #loops through
        j = i - 1 #prev
        curr_val = alist[i] #next
        while j >= 0: #assume first is sorted
            comp_counter += 1
            if alist[j] > curr_val: #if the prev > next
                alist[j + 1] = alist[j] #set the prev to the greater value
                j -= 1 #keep going down the set
            else: #otherwise skip
                break
        alist[j + 1] = curr_val #set the cur j val to the i val, ie final insert

    return comp_counter


def main():

    for num in [1000, 2000, 4000, 8000, 16000, 32000]:
        random.seed(1234)
        randoms = random.sample(range(1000000), num)  # Generate num random numbers from 0 to 999,999
        start_time = time.time()
        comps = insertion_sort(randoms)
        stop_time = time.time()
        print("n:", num, "- comps:", comps, "- time:", stop_time - start_time)

if __name__ == '__main__':
    main()

