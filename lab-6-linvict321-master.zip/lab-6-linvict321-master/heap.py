from dataclasses import dataclass
from typing import Any, List

@dataclass
class MinHeap:
    heap_capacity: int = 50          # default capacity of heap is 50

    def __post_init__(self) -> None:
        self.heap = [0]*(self.heap_capacity+1)      # index 0 not used for heap
        self.num_items = 0                          # empty heap

    def enqueue(self, item: Any) -> None:
        """inserts 'item' into the heap
        Raises IndexError if there is no room in the heap"""
        if self.num_items == self.heap_capacity:
            raise IndexError
        if not isinstance(item, int):
            raise TypeError

        self.num_items += 1
        if self.num_items >= len(self.heap):
            self.heap.append(item)
        else:
            self.heap[self.num_items] = item
        self.perc_up(self.num_items)

    def peek(self) -> Any:
        """returns root of heap (highest priority) without changing the heap
        Raises IndexError if the heap is empty"""
        if self.num_items == 0:
            raise IndexError
        return self.heap[1]

    def dequeue(self) -> Any:
        """returns item at root (highest priority) - removes it from the heap and restores the heap property
           Raises IndexError if the heap is empty"""
        if self.is_empty():
          raise IndexError

        temp = self.heap[1]
        self.heap[1] = self.heap[self.num_items] #swap first and last one
        self.num_items -= 1 #remove last one, which is the swapped first one
        self.perc_down(1) #perc down the current root which is the biggest number, but should be smallest
        return temp


    def contents(self) -> List:
        """returns a list of contents of the heap in the order it is stored internal to the heap.
        (This may be useful for in testing your implementation.)
        If heap is empty, returns empty list []"""
        final: List[Any] = []
        if self.is_empty():
            return final
        for n in range(1, self.num_items + 1):
            final.append(self.heap[n])
        return final

    def build_heap(self, alist: List) -> None:
        """Discards the items in the current heap and builds a heap from
        the items in alist using the bottom up method.
        If the capacity of the current heap is less than the number of
        items in alist, the capacity of the heap will be increased to accommodate the items in alist"""
        if not all(isinstance(item, int) for item in alist):
            raise TypeError

        self.num_items = len(alist)
        self.heap = [0] + alist[:]
        i = self.num_items // 2
        while (i > 0):
            self.perc_down(i)
            i = i - 1

    def is_empty(self) -> bool:
        """returns True if the heap is empty, false otherwise"""
        if self.num_items == 0:
            return True
        return False

    def is_full(self) -> bool:
        """returns True if the heap is full, false otherwise"""
        if self.num_items == self.heap_capacity:
            return True
        return False

    def capacity(self) -> int:
        """This is the maximum number of a entries the heap can hold, which is
        1 less than the number of entries that the array allocated to hold the heap can hold"""
        return self.heap_capacity

    def size(self) -> int:
        """the actual number of elements in the heap, not the capacity"""
        return self.num_items

    def perc_down(self,i: int) -> None:
        """where the parameter i is an index in the heap and perc_down moves the element stored
        at that location to its proper place in the heap rearranging elements as it goes."""
        while i*2 <= self.num_items:
            x = self.minChild(i)
            if self.heap[i] > self.heap[x]:
                temp = self.heap[x]
                self.heap[x] = self.heap[i]
                self.heap[i] = temp
            i = x #keep going until it reaches the end

    def minChild(self, i:int) -> int:
        if i * 2 + 1 > self.num_items:
            return i * 2 #return the lesser one
        else:
            if self.heap[i*2] < self.heap[i*2 + 1]: #see if right side is bigger, then put on right side
                return i * 2
            else: #if left side is bigger, put it on left
                return i * 2 + 1

    def perc_up(self,i: int) -> None:
        """where the parameter i is an index in the heap and perc_up moves the element stored
        at that location to its proper place in the heap rearranging elements as it goes."""
        while i//2 > 0:
            if self.heap[i] < self.heap[i//2]:
                temp = self.heap[i//2]
                self.heap[i//2] = self.heap[i]
                self.heap[i] = temp
            i = i//2

    def heap_sort_ascending(self, alist: List) -> None:
        """perform heap sort on input alist in ascending order
        This method will discard the current contents of the heap, build a new heap using
        the items in alist, and mutate alist to put the items in ascending order"""
        if not all(isinstance(item, int) for item in alist):
            raise TypeError
        self.build_heap(alist)
        for i in range(len(alist)):
            alist[i] = self.dequeue()

