# Start of unittest - add to completely test functions in exp_eval!

import unittest
from exp_eval import *

class test_expressions(unittest.TestCase):

    def test_postfix_eval_01a(self) -> None:
        self.assertAlmostEqual(postfix_eval("3 5 +"), 8)#

    def test_postfix_eval_01b(self) -> None:
        self.assertAlmostEqual(postfix_eval("8 1 >>"), 4)
        self.assertAlmostEqual(postfix_eval("8 1 <<"), 16)

    def test_postfix_eval_01c(self) -> None:
        self.assertAlmostEqual(postfix_eval("8 2 **"), 64)

    def test_postfix_eval_01d(self) -> None:
        self.assertAlmostEqual(postfix_eval("18.5 -2 *"), -37)
        self.assertAlmostEqual(postfix_eval("-18.52 -0.78 +"), -19.3)

    def test_postfix_eval_02(self) -> None:
        try:
            postfix_eval("blah")
            self.fail()     # pragma: no cover
        except PostfixFormatException as e:
            self.assertEqual(str(e), "Invalid token")

    def test_postfix_eval_03a(self) -> None:
        try:
            postfix_eval("4 +")
            self.fail()    # pragma: no cover
        except PostfixFormatException as e:
            self.assertEqual(str(e), "Insufficient operands")

    def test_postfix_eval_03b(self) -> None:
        try:
            postfix_eval("")
            self.fail()     # pragma: no cover
        except PostfixFormatException as e:
            self.assertEqual(str(e), "Insufficient operands")

    def test_postfix_eval_04(self) -> None:
        try:
            postfix_eval("1 2 3 +")
            self.fail()     # pragma: no cover
        except PostfixFormatException as e:
            self.assertEqual(str(e), "Too many operands")

    def test_infix_to_postfix_01a(self) -> None:
        self.assertEqual(infix_to_postfix("6 - 3"), "6 3 -")
        self.assertEqual(infix_to_postfix("6"), "6")
        self.assertEqual(infix_to_postfix("32 >> 2 >> 1"), "32 2 >> 1 >>")

    def test_infix_to_postfix_01b(self) -> None:
        self.assertEqual(infix_to_postfix("32 >> 2 << 1"), "32 2 >> 1 <<")

    def test_infix_to_postfix_01c(self) -> None:
        self.assertEqual(infix_to_postfix("3 ** 2 ** 2"), "3 2 2 ** **")

    def test_infix_to_postfix_02(self) -> None:
        self.assertEqual(infix_to_postfix("( 5 - 3 ) * 4"), "5 3 - 4 *")
        self.assertEqual(infix_to_postfix("3 + 4 * 2 / ( 1 - 5 ) ** 2 ** 3"), "3 4 2 * 1 5 - 2 3 ** ** / +")

    def test_infix_to_postfix_03(self) -> None:
        self.assertEqual(infix_to_postfix("70 - -3 * 10"), "70 -3 10 * -")

    def test_infix_to_postfix_04(self) -> None:
        self.assertEqual(infix_to_postfix("70.52 - 3.5 * 10.05"), "70.52 3.5 10.05 * -")

    def test_infix_to_postfix_05(self) -> None:
        self.assertEqual(infix_to_postfix("-70.52 - 3.5 * 10.05"), "-70.52 3.5 10.05 * -")

    def test_prefix_to_postfix(self) -> None:
        self.assertEqual(prefix_to_postfix("* - 3 / 2 1 - / 4 5 6"), "3 2 1 / - 4 5 / 6 - *")

    def test_extra_cases(self) -> None:
        try:
            postfix_eval("8 0 /")
            self.fail()    # pragma: no cover
        except PostfixFormatException as e:
            self.assertEqual(str(e), "Division by zero")

        with self.assertRaises(PostfixFormatException) as context:
            infix_to_postfix("( 3 + 4")
        self.assertEqual(str(context.exception), "Mismatched parentheses")

        self.assertEqual(infix_to_postfix("3 ** 2 ** 2"), "3 2 2 ** **")

        self.assertEqual(infix_to_postfix("3 * 4 + 5"), "3 4 * 5 +")

        try:
            infix_to_postfix("e")
            self.fail()  # pragma: no cover
        except PostfixFormatException as e:
            self.assertEqual(str(e), "Invalid token")

    def test_extra_cases2(self) -> None:
        with self.assertRaises(PostfixFormatException) as context:
            infix_to_postfix("( 3 + 4 ) )")
        self.assertEqual(str(context.exception), "Mismatched parentheses")

        with self.assertRaises(PostfixFormatException) as context:
            prefix_to_postfix("+")
        self.assertEqual(str(context.exception), "Insufficient operands")

        with self.assertRaises(PostfixFormatException) as context:
            prefix_to_postfix("+ +")
        self.assertEqual(str(context.exception), "Insufficient operands")

        try:
            prefix_to_postfix("4 +")
        except PostfixFormatException as e:
            self.assertEqual(str(e), "Insufficient operands")

        try:
            prefix_to_postfix("a")
        except PostfixFormatException as e:
            self.assertEqual(str(e), "Invalid token")

        try:
            prefix_to_postfix("1 + 4 5")
        except PostfixFormatException as e:
            self.assertEqual(str(e), "Too many operands")

        self.assertEqual(infix_to_postfix("5 << 3 ** 2"), "5 3 << 2 **")

        with self.assertRaises(PostfixFormatException) as context:
            prefix_to_postfix("+ 3 4 5")
        self.assertEqual(str(context.exception), "Too many operands")

if __name__ == "__main__":
    unittest.main()
