from stack_array import Stack
import operator

# You should not change this Exception class!
class PostfixFormatException(Exception):
    pass

def postfix_eval(input_str: str) -> float: #office hours: ask if i need to account for errors
    """Evaluates a postfix expression"""
    """Input argument:  a string containing a postfix expression where tokens 
    are space separated.  Tokens are either operators + - * / ** << >> or numbers (integers or floats)
    Returns the result of the expression evaluation. 
    Raises an PostfixFormatException if the input is not well-formed"""
    new_list = input_str.split(" ") if input_str.strip() else []  #creates a list of the split
    ops = {"+": operator.add, "-": operator.sub, "*":operator.mul, "/": operator.truediv, "**": operator.pow, "<<": operator.lshift, ">>": operator.rshift}
    postfix_stack = Stack(len(new_list))

    for token in new_list:
        if token in ops:
            try:
                b = postfix_stack.pop()
                a = postfix_stack.pop()
            except IndexError:
                raise PostfixFormatException('Insufficient operands')

            try:
                if token in ["<<", ">>"]:
                    result = ops[token](int(a), int(b))
                else:
                    result = ops[token](a, b)
                #gets the operator
            except ZeroDivisionError:
                raise PostfixFormatException('Division by zero')

            postfix_stack.push(result)
        else: #convert to number later b/c that way it wont convert the operators first
            try:
                num = float(token)
                postfix_stack.push(num)
            except ValueError:
                raise PostfixFormatException('Invalid token')

    if postfix_stack.size() > 1:
        raise PostfixFormatException("Too many operands")

    if postfix_stack.size() == 0: #
        raise PostfixFormatException('Insufficient operands')

    return postfix_stack.pop()

def infix_to_postfix(input_str: str) -> str:
    """Converts an infix expression to an equivalent postfix expression"""
    """Input argument:  a string containing an infix expression where tokens are 
    space separated.  Tokens are either operators + - * / ** << >> or numbers (integers or floats)
    Returns a String containing a postfix expression """
    new_list = input_str.split(" ")  # creates a list of the split
    ops = {"+": operator.add, "-": operator.sub, "*": operator.mul, "/": operator.truediv, "**": operator.pow,
           "<<": operator.lshift, ">>": operator.rshift}
    operator_stack = Stack(len(new_list))
    precedence = {"<<": 4, ">>": 4, "**": 3, "*": 2, "/": 2, "+": 1, "-": 1}

    final_list = []
    for token in new_list:
        try:
            float(token)
            final_list.append(token)
        except ValueError:
            if token == "(":
                operator_stack.push(token)
            elif token == ")":
                while not operator_stack.is_empty() and operator_stack.peek() != "(":
                    final_list.append(operator_stack.pop())
                if operator_stack.is_empty():
                    raise PostfixFormatException("Mismatched parentheses")
                operator_stack.pop()
            elif token in precedence:
                while not operator_stack.is_empty() and operator_stack.peek() in precedence:
                    top_op = operator_stack.peek() # only stop early for ** bc it's right-associative
                    if token == "**":
                        if precedence[token] < precedence[top_op]:
                            final_list.append(operator_stack.pop())
                        else:
                            break
                    else:
                        if precedence[token] <= precedence[top_op]:
                            final_list.append(operator_stack.pop())
                        else:
                            break
                operator_stack.push(token)
            else:
                raise PostfixFormatException("Invalid token")

    while not operator_stack.is_empty():
        top = operator_stack.pop()
        if top in ("(", ")"):
            raise PostfixFormatException("Mismatched parentheses")
        final_list.append(top)

    return " ".join(final_list)

def prefix_to_postfix(input_str: str) -> str:
    """Converts a prefix expression to an equivalent postfix expression"""
    """Input argument: a string containing a prefix expression where tokens are 
    space separated.  Tokens are either operators + - * / ** << >> or numbers (integers or floats)
    Returns a String containing a postfix expression(tokens are space separated)"""
    new_list = input_str.split(" ")  # creates a list of the split
    ops = {"+": operator.add, "-": operator.sub, "*": operator.mul, "/": operator.truediv, "**": operator.pow,
           "<<": operator.lshift, ">>": operator.rshift}
    stacklist = Stack(len(new_list))

    for token in reversed(new_list):
        if token in ops:

            if stacklist.size() < 2:
                raise PostfixFormatException("Insufficient operands")
            op1 = stacklist.pop()
            op2 = stacklist.pop()
            temp_str = f"{op1} {op2} {token}"
            stacklist.push(temp_str)

        else:
            try:
                float(token)
                stacklist.push(token)
            except ValueError:
                raise PostfixFormatException("Invalid token")

    if stacklist.size() != 1:
        raise PostfixFormatException("Too many operands")

    return stacklist.pop()

