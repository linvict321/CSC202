from dataclasses import dataclass
from typing import TypeAlias, Dict, Union, List, Optional
from stack_array import * # Needed for Depth First Search
from queue_array import * # Needed for Breadth First Search


MaybeVertex: TypeAlias = Union[None, 'Vertex']

@dataclass
class Vertex:
    id: Any

    def __post_init__(self) -> None:
        '''Add other attributes as necessary'''
        self.adjacent_to: List = []

class Graph:
    '''Add additional helper methods if necessary.'''
    def __init__(self, filename: str):
        '''reads in the specification of a graph and creates a graph using an adjacency list representation.  
           You may assume the graph is not empty and is a correct specification.  E.g. each edge is 
           represented by a pair of vertices.  Note that the graph is not directed so each edge specified 
           in the input file should appear on the adjacency list of each vertex of the two vertices associated 
           with the edge.'''
        self.vertex_dict: Dict[Any, Vertex] = {}
        try:
            with open(filename, 'r') as file:
                for line in file:
                    v1, v2 = line.strip().split()
                    self.add_vertex(v1)
                    self.add_vertex(v2)
                    self.add_edge(v1, v2)
        except:
            raise FileNotFoundError

    def add_vertex(self, key: Any) -> None:
        '''Add vertex to graph, only if the vertex is not already in the graph.'''
        if key not in self.vertex_dict:
            self.vertex_dict[key] = Vertex(key)

    def get_vertex(self, key: Any) -> Optional[Vertex]:
        '''Return the Vertex object associated with the id. If id is not in the graph, return None'''
        if key not in self.vertex_dict:
            return None
        return self.vertex_dict[key]

    def add_edge(self, v1: Any, v2: Any) -> None:
        '''v1 and v2 are vertex id's. As this is an undirected graph, add an 
           edge from v1 to v2 and an edge from v2 to v1.  You can assume that
           v1 and v2 are already in the graph'''
        self.vertex_dict[v1].adjacent_to.append(self.vertex_dict[v2])
        self.vertex_dict[v2].adjacent_to.append(self.vertex_dict[v1])

    def get_vertices(self) -> List:
        '''Returns a list of id's representing the vertices in the graph, in ascending order'''
        return sorted(self.vertex_dict.keys())

    def conn_components(self) -> List:
        '''Returns a list of lists.  For example, if there are three connected components 
           then you will return a list of three lists.  Each sub list should contain the
           vertices (in 'Python List Sort' order) in the connected component represented by that list.
           The overall list of lists should also be in order based on the first item of each sublist.
           This method MUST use Depth First Search logic!'''
        visited = set()
        final_comp = [] #return list
        for vertex_id in self.get_vertices():
            if vertex_id not in visited:
                stack = Stack(len(self.vertex_dict))
                component = []
                start_vertex = self.get_vertex(vertex_id)
                stack.push(start_vertex)
                visited.add(vertex_id)

                while not stack.is_empty():
                    current_vertex = stack.pop()
                    component.append(current_vertex.id)
                    for neighbor in current_vertex.adjacent_to:
                        if neighbor.id not in visited:
                            visited.add(neighbor.id)
                            stack.push(neighbor)

                final_comp.append(sorted(component))
        return final_comp



    def is_bipartite(self) -> bool:
        '''Returns True if the graph is bicolorable and False otherwise.
        This method MUST use Breadth First Search logic!
        Note: An empty graph meets the bipartite condition'''
        color = {}

        for vertex in self.get_vertices():
            if vertex not in color:
                q = Queue(len(self.vertex_dict))
                q.enqueue(self.get_vertex(vertex))
                color[vertex] = 0
                while not q.is_empty():
                    val = q.dequeue()
                    val_color = color[val.id]
                    for adj_vertex in val.adjacent_to:
                        if adj_vertex.id not in color:
                            color[adj_vertex.id] = 1- val_color
                            q.enqueue(adj_vertex)
                        elif color[adj_vertex.id] == val_color:
                            return False
        return True
